/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.paradoxbytes.sr.facade;

import com.paradoxbytes.sr.service.StudentRegistrationAppService;

import java.util.Collection;
import com.paradoxbytes.sr.to.Student;

/**
 *
 * @author Loric Madramootoo
 */
public class StudentRegistrationFacade implements java.io.Serializable {

    private final StudentRegistrationAppService srs;
    public static final long serialVersionUID = -6618469841127325843L;

    public StudentRegistrationFacade() {
        srs = new StudentRegistrationAppService();
    }

    public Student getStudentInformation(final int studentid) {

        return srs.getStudentInformation(studentid);

    }

    public Collection getCourses() {

        return srs.getCourses();

    }

     public boolean updateCourses(final int studentid, final int courseid){


        return srs.updateCourses(studentid, courseid);

    }




}
