/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.paradoxbytes.sr.interfaces;

import java.util.List;
import com.paradoxbytes.sr.to.Course;
/**
 *
 * @author Loric Madramootoo
 */
public interface ICourses {

    public List<Course> getAllCourses();

    public List<Course> getSpecificCourses(int studentid);

    public int getCourseCount(int studentid, int courseid);

}
