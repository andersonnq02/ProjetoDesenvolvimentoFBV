/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.paradoxbytes.sr.interfaces;

import java.util.List;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import com.paradoxbytes.sr.to.Course;
import com.paradoxbytes.sr.to.Student;

/**
 *
 * @author Loric Madramootoo
 */
public interface IRegisterManager {

    public List getStudentItems();

    public List getCourseItems();

    public String getSelectedStudent();

    public String getSelectedCourse();

    public void setSelectedStudent(String selectedStudent);

    public void setSelectedCourse(String selectedCourse);

    public Student getCurrentStudent();

    public void setCurrentStudent(Student currentStudent);

    public Student getNewStudent();

    public void setNewStudent(Student newStudent);

    public Student getUpdateStudent();

    public void setUpdateStudent(Student updateStudent);

    public Course getCurrentCourse();

    public void setCurrentCourse(Course currentCourse);

    public List getStudentCourses();

    public void setStudentCourses();

    public void studentValueChanged(ValueChangeEvent event);

    public void courseValueChanged(ValueChangeEvent event);

    public void addStudent(ActionEvent event);

    public void deleteStudent(ActionEvent event);

    public void updateStudent(ActionEvent event);

    public void addCourseToStudent(ActionEvent event);

    public void removeCourseFromStudent(ActionEvent event);
}
