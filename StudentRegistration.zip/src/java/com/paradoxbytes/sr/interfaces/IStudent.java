/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.paradoxbytes.sr.interfaces;

import java.util.List;
import com.paradoxbytes.sr.to.Course;
import com.paradoxbytes.sr.to.Student;


/**
 *
 * @author Loric Madramootoo
 */
public interface IStudent {

    public List<Course> getMyCourses(int studentid);

    public Student getMyInformation(int studentid);

    public boolean addToMyCourses(int studentid, int courseid);

    public boolean removeSpecificCourse(int studentid, int courseid);


}
