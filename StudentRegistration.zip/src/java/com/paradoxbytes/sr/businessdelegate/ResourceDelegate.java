/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.paradoxbytes.sr.businessdelegate;

import com.paradoxbytes.sr.facade.StudentRegistrationFacade;
import com.paradoxbytes.sr.to.Student;
import java.util.Collection;

/**
 *
 * @author Loric Madramootoo
 */
public class ResourceDelegate implements java.io.Serializable{

    private final StudentRegistrationFacade srf;

    public static final long serialVersionUID = -6618469841127325812L;


    public ResourceDelegate()
    {
      srf = new StudentRegistrationFacade();

    }

    public Student getStudentInformation(final int studentid) {

        return srf.getStudentInformation(studentid);

    }

    public Collection getCourses() {

        return srf.getCourses();

    }


    public boolean updateCourses(final int studentid, final int courseid){


        return srf.updateCourses(studentid, courseid);

    }


}
