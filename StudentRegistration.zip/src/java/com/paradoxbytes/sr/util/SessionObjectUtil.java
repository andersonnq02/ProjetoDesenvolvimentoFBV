/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.paradoxbytes.sr.util;

import com.paradoxbytes.sr.businessdelegate.ResourceDelegate;
import com.paradoxbytes.sr.to.Student;
import java.io.IOException;
import java.util.Collection;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author Loric Madramootoo
 */
public class SessionObjectUtil {

    private static ResourceDelegate businessdelegate;

    private SessionObjectUtil() {
    

    }

    public static void createSession(HttpServletRequest request) {

        final Log LOG = LogFactory.getLog(SessionObjectUtil.class);
        LOG.info(" Session creation");

        businessdelegate = new ResourceDelegate();
        HttpSession session = request.getSession();

        int studentid = Integer.parseInt((request.getUserPrincipal().getName()).substring(request.getUserPrincipal().getName().length() - 1, request.getUserPrincipal().getName().length()));

        Student student = businessdelegate.getStudentInformation(studentid);
        session.setAttribute("info", student);


        Collection courses = businessdelegate.getCourses();
        session.setAttribute("courses", courses);



    }

    public static void updateSession(HttpServletRequest request) {

        final Log LOG = LogFactory.getLog(SessionObjectUtil.class);
        LOG.info(" Session updated");

        businessdelegate = new ResourceDelegate();
        HttpSession session = request.getSession();
        session.removeAttribute("info");
        session.removeAttribute("courses");

        int studentid = Integer.parseInt((request.getUserPrincipal().getName()).substring(request.getUserPrincipal().getName().length() - 1, request.getUserPrincipal().getName().length()));

        Student student = businessdelegate.getStudentInformation(studentid);
        session.setAttribute("info", student);


        Collection courses = businessdelegate.getCourses();
        session.setAttribute("courses", courses);



    }

    public static void killSession(HttpServletRequest request) {

        request.getSession().invalidate();


    }
}
