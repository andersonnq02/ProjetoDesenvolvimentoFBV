package com.paradoxbytes.sr.util;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class ConnectionFactory {

    

    private ConnectionFactory()
    {
      try{
          Class.forName(FileUtil.getMySQLConfig().getProperty("datasource.classname"));
      }
      catch(ClassNotFoundException e)
      {

          Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, "ConnectionFactory ERROR: exception loading driver class");

      }



    }



    public static Connection getConnection() throws SQLException{


        return DriverManager.getConnection(FileUtil.getMySQLConfig().getProperty("datasource.url"),
                        FileUtil.getMySQLConfig().getProperty("datasource.username"),
                        FileUtil.getMySQLConfig().getProperty("datasource.password"));


    }





    public static void close(ResultSet rs)
    {
      try{
          rs.close();
      }
      catch(Exception ignored)
      {
       Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ignored.toString());
      }


    }


    public static void close(Statement stmt)
    {
      try{
          stmt.close();
      }
      catch(Exception ignored)
      {
       Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ignored.toString());
      }


    }


    public static void close(Connection conn)
    {
      try{
          conn.close();
      }
      catch(Exception ignored)
      {
       Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ignored.toString());
      }


    }





}
