package com.paradoxbytes.sr.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class FileUtil {

    private final static transient Properties MYSQLPROPERTIES = new Properties();
    private final static transient String MYSQLPROPERTIESFILENAME = "mysql.properties";

    private final static transient Properties PAGEEXPIREFILTERPROPERTIES = new Properties();
    private final static transient String PAGEEXPIREFILTERFILENAME = "expires.properties";

    private final static transient Properties DAOPROPERTIES = new Properties();
    private final static transient String DAOPROPERTIESFILENAME = "dao.properties";


    private FileUtil() {
    }

       public static Properties getPageExpireConfig() {

        final Log log = LogFactory.getLog(FileUtil.class);


        try {




            final InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(PAGEEXPIREFILTERFILENAME);

            if (input != null) {
                log.debug("Accessing page expire property file");

                PAGEEXPIREFILTERPROPERTIES.load(input);

                input.close();

            }


        } catch (IOException iox) {
            log.error("Could not access page expire property file: " + iox.toString());



        }


        return PAGEEXPIREFILTERPROPERTIES;
    }






    public static Properties getMySQLConfig() {

        final Log log = LogFactory.getLog(FileUtil.class);


        try {




            final InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(MYSQLPROPERTIESFILENAME);

            if (input != null) {
                log.debug("Accessing mysql property file");

                MYSQLPROPERTIES.load(input);

                input.close();

            }


        } catch (IOException iox) {
            log.error("Could not access mysql property file: " + iox.toString());



        }


        return MYSQLPROPERTIES;
    }



      public static Properties getDAOConfig() {

        final Log log = LogFactory.getLog(FileUtil.class);


        try {




            final InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(DAOPROPERTIESFILENAME);

            if (input != null) {
                log.debug("Accessing dao property file");

                DAOPROPERTIES.load(input);

                input.close();

            }


        } catch (IOException iox) {
            log.error("Could not access dao property file: " + iox.toString());



        }


        return DAOPROPERTIES;
    }






}
