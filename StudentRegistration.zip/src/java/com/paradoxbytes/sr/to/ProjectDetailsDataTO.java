/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.paradoxbytes.sr.to;

import java.util.Collection;

import com.paradoxbytes.sr.dao.HibernateDAOFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author Loric Madramootoo
 */
public class ProjectDetailsDataTO implements java.io.Serializable {


    private Object studentInformation;
    private Collection courseInformation;
    private boolean isCourseSelected;

    private static final Log LOG = LogFactory.getLog(ProjectDetailsDataTO.class);


    public void createStudentInformationResourceTO(final int studentid) {
        try {

            setStudentInformation( new HibernateDAOFactory().getStudentDAO().getMyInformation(studentid));

        } catch (InstantiationException e) {
            LOG.error("ProjectDetailsDataTO: " + e.toString());


        } catch (IllegalAccessException e) {
            LOG.error("ProjectDetailsDataTO: " + e.toString());


        }




    }

    public void createCourseInformationResourceTO() {
        try {

            setCourseInformation(new HibernateDAOFactory().getCourseDAO().getAllCourses());

        } catch (InstantiationException e) {
            LOG.error("ProjectDetailsDataTO: " + e.toString());


        } catch (IllegalAccessException e) {
            LOG.error("ProjectDetailsDataTO: " + e.toString());


        }

    }


    public void isStudentCourseSelected(final int studenid, final int courseid){

         try {

            setIsCourseSelected(new HibernateDAOFactory().getStudentDAO().addToMyCourses(studenid, courseid));

        } catch (InstantiationException e) {
            LOG.error("ProjectDetailsDataTO: " + e.toString());


        } catch (IllegalAccessException e) {
            LOG.error("ProjectDetailsDataTO: " + e.toString());


        }



    }



    public Collection getCourseInformation() {
        return courseInformation;
    }

    public void setCourseInformation(Collection courseInformation) {
        this.courseInformation = courseInformation;
    }

    public boolean isIsCourseSelected() {
        return isCourseSelected;
    }

    public void setIsCourseSelected(boolean isCourseSelected) {
        this.isCourseSelected = isCourseSelected;
    }

    public Object getStudentInformation() {
        return studentInformation;
    }

    public void setStudentInformation(Object studentInformation) {
        this.studentInformation = studentInformation;
    }




}
