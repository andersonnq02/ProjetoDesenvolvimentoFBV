/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.paradoxbytes.sr.to;

/**
 *
 * @author Loric Madramootoo
 */

import java.util.HashSet;
import java.util.Set;

/**
 * Represents a Course in the hibernate tutorial
 * Student Register example.
 */
public class Course implements java.io.Serializable{
    // unique course id
    private int courseId;
    // name of the course
    private String courseName;
    // description of the course
    private String description;
    // set of students that are related/registered for the course
    private Set students = new HashSet();

    /**
     * Default contructor.
     */
    public Course() {
    }

    /**
     * Creates a new instance of Course.
     * @param courseId course id.
     * @param courseName course name.
     * @param description description of the course.
     */
    public Course(int courseId, String courseName, String description){
        this.courseId = courseId;
        this.courseName = courseName;
        this.description = description;
    }

    /**
     * Gets the course Id of this course.
     * @return course id.
     */
    public int getCourseId(){
        return courseId;
    }

    /**
     * Sets the course id of this course.
     * @param course id.
     */
    public void setCourseId(int courseId){
        this.courseId = courseId;
    }

    /**
     * Gets the course name for this course.
     * @return course name.
     */
    public String getCourseName(){
        return courseName;
    }

    /**
     * Sets the course name for this course.
     * @param course name.
     */
    public void setCourseName(String courseName){
        this.courseName = courseName;
    }

    /**
     * Gets the description for this course.
     * @return description.
     */
    public String getDescription(){
        return description;
    }

    /**
     * Sets the description for this course.
     * @param description.
     */
    public void setDescription(String description){
        this.description = description;
    }

    /**
     * Gets the set of students for this course.
     * @return Set of students.
     */
    public Set getStudents(){
        return students;
    }

    /**
     * Sets the set of students for this course.
     * @param Set of students.
     */
    public void setStudents(Set students){
        this.students = students;
    }

    /**
     * Method used by the UI to clear information on the screen.
     * @return String used in the navigation rules.
     */
    public String clear(){
        courseId=0;
        courseName="";
        description="";
        return "clear";
    }
}

