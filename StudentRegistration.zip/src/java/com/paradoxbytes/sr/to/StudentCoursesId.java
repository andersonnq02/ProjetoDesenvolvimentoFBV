/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.paradoxbytes.sr.to;

/**
 *
 * @author Loric Madramootoo
 */
public class StudentCoursesId implements java.io.Serializable{

   private Long studentId;
   private Long courseId;

    public StudentCoursesId(Long studentId, Long courseId) {
        this.studentId = studentId;
        this.courseId = courseId;
    }

    public Long getCourseId() {
        return courseId;
    }

    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final StudentCoursesId other = (StudentCoursesId) obj;
        if (this.studentId != other.studentId && (this.studentId == null || !this.studentId.equals(other.studentId))) {
            return false;
        }
        if (this.courseId != other.courseId && (this.courseId == null || !this.courseId.equals(other.courseId))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + (this.studentId != null ? this.studentId.hashCode() : 0);
        hash = 47 * hash + (this.courseId != null ? this.courseId.hashCode() : 0);
        return hash;
    }

   

}
