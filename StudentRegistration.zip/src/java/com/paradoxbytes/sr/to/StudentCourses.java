/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.paradoxbytes.sr.to;

/**
 *
 * @author Loric Madramootoo
 */
public class StudentCourses {

 private StudentCoursesId studentCoursesId;

    public StudentCoursesId getStudentCoursesId() {
        return studentCoursesId;
    }

    public void setStudentCoursesId(StudentCoursesId studentCoursesId) {
        this.studentCoursesId = studentCoursesId;
    }




}
