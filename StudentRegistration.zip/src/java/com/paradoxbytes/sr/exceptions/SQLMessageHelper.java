package com.paradoxbytes.sr.exceptions;

import java.sql.SQLException;
import java.sql.SQLWarning;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SQLMessageHelper {

	public static void sqlmessages(SQLException sqle) {
		do {


                        Logger.getLogger(SQLMessageHelper.class.getPackage().getName()).log(Level.SEVERE, "Exception occurred:\nMessage: "
					+ sqle.getMessage());
                        Logger.getLogger(SQLMessageHelper.class.getPackage().getName()).log(Level.SEVERE, "SQL state: " + sqle.getSQLState());
                        Logger.getLogger(SQLMessageHelper.class.getPackage().getName()).log(Level.SEVERE, "Vendor code: " + sqle.getErrorCode());
                        Logger.getLogger(SQLMessageHelper.class.getPackage().getName()).log(Level.SEVERE, "\n------------------");

			//System.err.println("Exception occurred:\nMessage: "
			//		+ sqle.getMessage());
			//System.err.println("SQL state: " + sqle.getSQLState());
			//System.err.println("Vendor code: " + sqle.getErrorCode());
			//System.err.println("\n------------------");
		} while ((sqle = sqle.getNextException()) != null);

	}

	public static boolean checkForWarning(SQLWarning w) {

		if (w == null) {
			return false;
		}
		do {

                     Logger.getLogger(SQLMessageHelper.class.getPackage().getName()).log(Level.WARNING, "Warning:\nMessage: " + w.getMessage());
                        Logger.getLogger(SQLMessageHelper.class.getPackage().getName()).log(Level.WARNING, "SQL State: " + w.getSQLState());
                        Logger.getLogger(SQLMessageHelper.class.getPackage().getName()).log(Level.WARNING, "Vendor code: " + w.getErrorCode());
                        Logger.getLogger(SQLMessageHelper.class.getPackage().getName()).log(Level.WARNING, "\n------------------");



                        //System.err.println("Warning:\nMessage: " + w.getMessage());
			//System.err.println("SQL State: " + w.getSQLState());
			//System.err.println("Vendor code: " + w.getErrorCode());
			//System.err.println("\n------------------");

		} while ((w = w.getNextWarning()) != null);
		return true;
	}

}
