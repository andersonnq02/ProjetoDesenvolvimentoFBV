package com.paradoxbytes.sr.dao;

import com.paradoxbytes.sr.exceptions.DaoException;
import com.paradoxbytes.sr.exceptions.SQLMessageHelper;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.paradoxbytes.sr.interfaces.IStudent;
import com.paradoxbytes.sr.servicelocator.ServiceLocator;
import com.paradoxbytes.sr.to.Course;
import com.paradoxbytes.sr.to.Student;

import com.paradoxbytes.sr.util.ConnectionFactory;
import com.paradoxbytes.sr.util.FileUtil;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MYSQLStudentDAO implements IStudent {

    private Connection connection;
    private ServiceLocator service;
    private static final Log LOG = LogFactory.getLog(MYSQLStudentDAO.class);

    public MYSQLStudentDAO() throws DaoException {

        service = new ServiceLocator();

        try {

            connection = service.getDataSource(FileUtil.getMySQLConfig().getProperty("datasource.name")).getConnection();
            connection.setAutoCommit(false);



        } catch (Exception ex) {

            LOG.error("MYSQLStudentDAO:Error using jndi: " + ex.toString());
            try {

                Class.forName(FileUtil.getMySQLConfig().getProperty("datasource.classname"));

                connection = ConnectionFactory.getConnection();
                connection.setAutoCommit(false);

            } catch (SQLException e) {
                // TODO Auto-generated catch block
                LOG.error("MYSQLStudentDAO:Error using property file: " + e.toString());
                connection = null;

            } catch (Exception e) {
                // TODO Auto-generated catch block
                LOG.error("MYSQLStudentDAO:Error using property file: " + e.toString());
                connection = null;
            }
        }


    }

    @Override
    public List<Course> getMyCourses(int studentid) {

        List courses = null;

        try {
            courses = new MYSQLCoursesDAO().getSpecificCourses(studentid);
        } catch (DaoException ex) {
            LOG.error(ex.toString());
        }

        return courses;
    }

    public Student getMyInformation(int studentid) {


        java.sql.PreparedStatement stmt = null;

        ResultSet rs = null;

        Student student = new Student();


        String sql = "Select student_id, first_name, last_name, address from students where student_id = ?";

        try {


            stmt = connection.prepareStatement(sql);

            stmt.setInt(1, studentid);

            rs = stmt.executeQuery();

            while (rs.next()) {


                student.setStudentId(rs.getInt(1));
                SQLMessageHelper.checkForWarning(rs.getWarnings());
                student.setFirstName(rs.getString(2));
                SQLMessageHelper.checkForWarning(rs.getWarnings());
                student.setLastName(rs.getString(3));
                SQLMessageHelper.checkForWarning(rs.getWarnings());
                student.setAddress(rs.getString(4));
                SQLMessageHelper.checkForWarning(rs.getWarnings());

                final Set courses = new HashSet(1);
                courses.add(getMyCourses(studentid));
                student.setCourses(courses);


            }


        } catch (SQLException sqle) {
            SQLMessageHelper.sqlmessages(sqle);
        } catch (Exception e) {
            LOG.error(e.toString());

        } finally {
            try {
                if (connection != null) {
                    connection.commit();
                    connection.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }

            } catch (Exception e) {
                try {
                    connection.rollback();

                } catch (Exception ignored) {
                }
                LOG.error(e.toString());
            }

        }

        return student;





    }

    public boolean addToMyCourses(int studentid, int courseid) {

        boolean result = false;

        try {
            if (new MYSQLCoursesDAO().getCourseCount(studentid, courseid) == 0) {

                java.sql.PreparedStatement pstmt = null;

                String sql = "INSERT INTO student_courses VALUES(?,?)";


                try {


                    pstmt = connection.prepareStatement(sql);

                    pstmt.setInt(1, studentid);
                    pstmt.setInt(2, courseid);

                    pstmt.executeUpdate();

                    result = true;


                } catch (SQLException sqle) {
                    SQLMessageHelper.sqlmessages(sqle);
                } catch (Exception e) {
                    LOG.error(e.toString());

                } finally {
                    try {
                        if (connection != null) {
                            connection.commit();
                            connection.close();
                        }
                        if (pstmt != null) {
                            pstmt.close();
                        }
                    } catch (Exception e) {
                        try {
                            connection.rollback();

                        } catch (Exception ignored) {
                        }
                        LOG.error(e.toString());
                    }

                }




            }

        } catch (DaoException ex) {
            LOG.error(ex.toString());
        }




        return result;



    }

    public boolean removeSpecificCourse(int studentid, int courseid) {

      boolean result = false;

        try {
            if (new MYSQLCoursesDAO().getCourseCount(studentid, courseid) == 0) {

                java.sql.PreparedStatement pstmt = null;

                String sql = "Delete From student_courses where studentid = ? and courseid = ?";


                try {

                    connection.setAutoCommit(false);

                    pstmt = connection.prepareStatement(sql);

                    pstmt.setInt(1, studentid);
                    pstmt.setInt(2, courseid);

                    pstmt.executeUpdate();

                    result = true;


                } catch (SQLException sqle) {
                    SQLMessageHelper.sqlmessages(sqle);
                } catch (Exception e) {
                    LOG.error(e.toString());

                } finally {
                    try {
                        if (connection != null) {
                            connection.commit();
                            connection.setAutoCommit(true);
                            connection.close();
                        }
                        if (pstmt != null) {
                            pstmt.close();
                        }
                    } catch (Exception e) {
                        try {
                            connection.rollback();

                        } catch (Exception ignored) {
                        }
                        LOG.error(e.toString());
                    }

                }




            }

        } catch (DaoException ex) {
            LOG.error(ex.toString());
        }




        return result;





    }
}
