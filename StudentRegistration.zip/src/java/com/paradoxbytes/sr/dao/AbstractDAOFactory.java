package com.paradoxbytes.sr.dao;

import com.paradoxbytes.sr.enums.Data;


public abstract class AbstractDAOFactory {



    public static AbstractDAOFactory getDAOFactory(final Data type) {
        switch (type) {
            case MYSQL:
                return new MYSQLDAOFactory();
            case HIBERNATE:
                return new HibernateDAOFactory();
            default:
                return null;

        }

    }
}
