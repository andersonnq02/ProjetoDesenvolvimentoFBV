/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.paradoxbytes.sr.dao;

import com.paradoxbytes.sr.util.HibernateUtil;
import java.util.List;
import org.hibernate.*;
import com.paradoxbytes.sr.interfaces.ICourses;
import com.paradoxbytes.sr.to.Course;
import java.math.BigInteger;

/**
 *
 * @author Loric Madramootoo
 */
public class HCoursesDAO implements ICourses, java.io.Serializable {


   

    @Override
    public List<Course> getAllCourses() {

        final Session session = HibernateUtil.currentSession();

        // using embedded sql
        SQLQuery sql = session.createSQLQuery("select * from courses").addEntity(Course.class);

        return sql.list();
    }

    @Override
    public List<Course> getSpecificCourses(int studentid) {

        final Session session = HibernateUtil.currentSession();
        // using embedded sql
        SQLQuery sql = session.createSQLQuery("Select * from courses where course_id in (Select course_id  From student_courses  where student_id =" + studentid + ")").addEntity(Course.class);

        return sql.list();

    }



   public int getCourseCount(int studentid, int courseid)
   {
     
    final Session session = HibernateUtil.currentSession();

    SQLQuery sql = session.createSQLQuery("Select count(course_id) from student_courses where course_id =" + courseid+" and student_id =" + studentid+"" );

    return ((BigInteger)(sql.uniqueResult())).intValue();
   }
}
