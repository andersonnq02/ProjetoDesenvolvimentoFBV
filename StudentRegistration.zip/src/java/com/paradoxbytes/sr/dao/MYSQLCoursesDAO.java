package com.paradoxbytes.sr.dao;

import com.paradoxbytes.sr.exceptions.DaoException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.paradoxbytes.sr.interfaces.ICourses;
import com.paradoxbytes.sr.servicelocator.ServiceLocator;
import com.paradoxbytes.sr.to.Course;

import com.paradoxbytes.sr.util.ConnectionFactory;
import com.paradoxbytes.sr.util.FileUtil;

import com.paradoxbytes.sr.exceptions.SQLMessageHelper;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MYSQLCoursesDAO implements ICourses {

    private Connection connection;
    private ServiceLocator service;
    private static final Log LOG = LogFactory.getLog(MYSQLCoursesDAO.class);

    public MYSQLCoursesDAO() throws DaoException {

        service = new ServiceLocator();

        try {

            connection = service.getDataSource(FileUtil.getMySQLConfig().getProperty("datasource.name")).getConnection();
            connection.setAutoCommit(false);



        } catch (Exception ex) {

            LOG.error("MYSQLCoursesDAO:Error using jndi: " + ex.toString());
            try {

                Class.forName(FileUtil.getMySQLConfig().getProperty("datasource.classname"));

                connection = ConnectionFactory.getConnection();
                connection.setAutoCommit(false);

            } catch (SQLException e) {
                // TODO Auto-generated catch block
                LOG.error("MYSQLCoursesDAO:Error using property file: " + e.toString());
                connection = null;

            } catch (Exception e) {
                // TODO Auto-generated catch block
                LOG.error("MYSQLCoursesDAO:Error using property file: " + e.toString());
                connection = null;
            }
        }


    }

    @Override
    public List<Course> getAllCourses() {

        java.sql.PreparedStatement stmt = null;

        ResultSet rs = null;

        ArrayList<Course> courses = new ArrayList<Course>();

        String sql = "Select course_id, course_name, description from courses";

        try {


            stmt = connection.prepareStatement(sql);

            rs = stmt.executeQuery();


            while (rs.next()) {

                Course course = new Course();
                course.setCourseId(rs.getInt(1));
                SQLMessageHelper.checkForWarning(rs.getWarnings());
                course.setCourseName(rs.getString(2));
                SQLMessageHelper.checkForWarning(rs.getWarnings());
                course.setDescription(rs.getString(3));
                SQLMessageHelper.checkForWarning(rs.getWarnings());

                courses.add(course);
            }



        } catch (SQLException sqle) {
            SQLMessageHelper.sqlmessages(sqle);
        } catch (Exception e) {
            LOG.error(e.toString());

        } finally {
            try {
                if (connection != null) {
                    connection.commit();
                    connection.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }

            } catch (Exception e) {
                try {
                    connection.rollback();

                } catch (Exception ignored) {
                }
                LOG.error(e.toString());
            }

        }

        return courses;

    }

    @Override
    public List<Course> getSpecificCourses(int studentid) {



        java.sql.PreparedStatement stmt = null;

        ResultSet rs = null;

        ArrayList<Course> courses = new ArrayList<Course>();

        String sql = "Select course_id, course_name, description from courses where course_id in (Select course_id  From student_courses where student_id = ?)";

         try {


            stmt = connection.prepareStatement(sql);

            stmt.setInt(1, studentid);

            rs = stmt.executeQuery();

             while (rs.next()) {

             Course course = new Course();
                course.setCourseId(rs.getInt(1));
                SQLMessageHelper.checkForWarning(rs.getWarnings());
                course.setCourseName(rs.getString(2));
                SQLMessageHelper.checkForWarning(rs.getWarnings());
                course.setDescription(rs.getString(3));
                SQLMessageHelper.checkForWarning(rs.getWarnings());

                courses.add(course);


           }


    }
     catch (SQLException sqle) {
            SQLMessageHelper.sqlmessages(sqle);
        } catch (Exception e) {
            LOG.error(e.toString());

        } finally {
            try {
                if (connection != null) {
                    connection.commit();
                    connection.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }

            } catch (Exception e) {
                try {
                    connection.rollback();

                } catch (Exception ignored) {
                }
                LOG.error(e.toString());
            }

        }

        return courses;

      

    }

    @Override
    public int getCourseCount(int studentid, int courseid) {


        java.sql.PreparedStatement stmt = null;

        ResultSet rs = null;

        String sql = "Select count(course_id) from student_courses where course_id =? and student_id =?";

        int amount = -1;

        try {


            stmt = connection.prepareStatement(sql);

            stmt.setInt(1, courseid);
            stmt.setInt(2, studentid);

            rs = stmt.executeQuery();

            while (rs.next()) {

            amount = rs.getInt(1);



           }


    }
  catch (SQLException sqle) {
            SQLMessageHelper.sqlmessages(sqle);
        } catch (Exception e) {
            LOG.error(e.toString());

        } finally {
            try {
                if (connection != null) {
                    connection.commit();
                    connection.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }

            } catch (Exception e) {
                try {
                    connection.rollback();

                } catch (Exception ignored) {
                }
                LOG.error(e.toString());
            }

        }


   return amount;
   
 }


}
