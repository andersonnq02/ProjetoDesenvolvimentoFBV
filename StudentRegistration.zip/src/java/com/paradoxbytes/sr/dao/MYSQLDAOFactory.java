package com.paradoxbytes.sr.dao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.paradoxbytes.sr.exceptions.DaoException;
import com.paradoxbytes.sr.util.FileUtil;

public class MYSQLDAOFactory extends AbstractDAOFactory {

    private static final String DATASOURCE_DB_NAME = FileUtil.getMySQLConfig().getProperty("datasource.name");

    private static final Log LOG = LogFactory.getLog(MYSQLDAOFactory.class);


    public MYSQLStudentDAO getStudentDAO() throws InstantiationException, IllegalAccessException, DaoException {
        LOG.info("Creation of student dao using mysql");
        return (MYSQLStudentDAO) createDAO(MYSQLStudentDAO.class);
    }


    public MYSQLCoursesDAO getCourseDAO() throws InstantiationException, IllegalAccessException, DaoException {
        LOG.info("Creation of student dao using mysql");
        return (MYSQLCoursesDAO) createDAO(MYSQLCoursesDAO.class);
    }

  


    @SuppressWarnings({"unchecked"})
    private Object createDAO(final Class classObj) throws DaoException, InstantiationException, IllegalAccessException {
        return classObj.newInstance();


    }
}
