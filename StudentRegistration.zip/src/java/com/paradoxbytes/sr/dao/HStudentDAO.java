/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.paradoxbytes.sr.dao;

import com.paradoxbytes.sr.interfaces.IStudent;
import com.paradoxbytes.sr.to.Course;
import com.paradoxbytes.sr.to.Student;
import com.paradoxbytes.sr.to.StudentCourses;
import com.paradoxbytes.sr.to.StudentCoursesId;

import com.paradoxbytes.sr.util.HibernateUtil;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.*;

/**
 *
 * @author Loric Madramootoo
 */
public class HStudentDAO implements IStudent {

    public List<Course> getMyCourses(int studentid) {
        return new HCoursesDAO().getSpecificCourses(studentid);
    }

    public boolean removeSpecificCourse(int studentid, int courseid) {
        boolean result = false;

        if (new HCoursesDAO().getCourseCount(studentid, courseid) != 0) {

            Session session = HibernateUtil.currentSession();
            session.beginTransaction();
            //SQLQuery sql = session.createSQLQuery("delete from student_courses where student_id= "+studentid+" and course_id= "+courseid);
            StudentCourses studentCourses = new StudentCourses();
            StudentCoursesId studentCourseid = new StudentCoursesId(new Long(studentid), new Long(courseid));
            studentCourses.setStudentCoursesId(studentCourseid);

            session.delete(studentCourses);
            session.getTransaction().commit();

            //result = sql.executeUpdate();
            result = true;
         
        }

        return result;
    }

    public boolean addToMyCourses(int studentid, int courseid) {
        boolean result = false;

        if (new HCoursesDAO().getCourseCount(studentid, courseid) == 0) {

            Session session = HibernateUtil.currentSession();

            StudentCourses studentCourses = new StudentCourses();
            StudentCoursesId studentCourseid = new StudentCoursesId(new Long(studentid), new Long(courseid));
            studentCourses.setStudentCoursesId(studentCourseid);

            session.beginTransaction();
            session.save(studentCourses);
            session.getTransaction().commit();

            result = true;
        }

        return result;
    }

    public Student getMyInformation(int studentid) {

        final Session session = HibernateUtil.currentSession();
        // using embedded sql
        SQLQuery sql = session.createSQLQuery("Select * from students where student_id =" + studentid + "").addEntity(Student.class);

        Student student = new Student();

        List<Student> students = sql.list();

        for (Student information : students) {
            int id = information.getStudentId();
            String firstname = information.getFirstName();
            String lastname = information.getLastName();
            String address = information.getAddress();
            student.setStudentId(studentid);
            student.setFirstName(firstname);
            student.setLastName(lastname);
            student.setAddress(address);
            Set courses = new HashSet(1);
            courses.add(getMyCourses(studentid));
            student.setCourses(courses);

        }

        return student;

    }
}
