/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.paradoxbytes.sr.dao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author Loric Madramootoo
 */
public class HibernateDAOFactory extends AbstractDAOFactory {

    private static final Log LOG = LogFactory.getLog(HibernateDAOFactory.class);

    public HStudentDAO getStudentDAO() throws InstantiationException, IllegalAccessException {
        LOG.info("Creation of student dao using hibernate");
        return (HStudentDAO) createDAO(HStudentDAO.class);
    }

    public HCoursesDAO getCourseDAO() throws InstantiationException, IllegalAccessException {
        LOG.info("Creation of course dao using hibernate");
        return (HCoursesDAO) createDAO(HCoursesDAO.class);
    }

    public HRegisterManagerDAO getRegisterManagerDAO() throws InstantiationException, IllegalAccessException {
        LOG.info("Creation of registermanager dao using hibernate");
        return (HRegisterManagerDAO) createDAO(HRegisterManagerDAO.class);
    }

    private Object createDAO(final Class classObj) throws InstantiationException, IllegalAccessException {
        return classObj.newInstance();


    }
}
