
package com.paradoxbytes.sr.dao;

import com.paradoxbytes.sr.util.HibernateUtil;
import com.paradoxbytes.sr.to.Student;
import com.paradoxbytes.sr.to.Course;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import com.paradoxbytes.sr.interfaces.IRegisterManager;
import org.hibernate.Query;
import org.hibernate.Session;
import javax.faces.model.SelectItem;

/**
 * Represents the Utility class for the StudentRegister application which uses
 * Hibernate to connect and interact with a MySql database.
 **/
public class HRegisterManagerDAO {

    

}
