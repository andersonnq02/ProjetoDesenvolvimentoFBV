/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.paradoxbytes.sr.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.paradoxbytes.sr.businessdelegate.ResourceDelegate;
import com.paradoxbytes.sr.to.Student;
import com.paradoxbytes.sr.util.SessionObjectUtil;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 *
 * @author Loric Madramootoo
 */
public class CoursesController extends HttpServlet {

    protected ResourceDelegate businessdelegate;

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {


        final Log LOG = LogFactory.getLog(CoursesController.class);

        businessdelegate = new ResourceDelegate();

        final int studentid =  ((Student)(request.getSession().getAttribute("info"))).getStudentId();
        final int courseid = Integer.parseInt(request.getParameter("selectedcourseid"));

        final boolean result = businessdelegate.updateCourses(studentid, courseid);
        
        if(result){
            LOG.info("Update was sucessful");
            LOG.info("Session object will be updated");
            SessionObjectUtil.updateSession(request);
            LOG.info("Session was updated");
        }
        else{
            LOG.info("Update was unsucessful");
        }

        LOG.info("Redirect to index page");
        response.sendRedirect("index.htm");

    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
