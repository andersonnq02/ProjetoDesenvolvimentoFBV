package com.paradoxbytes.sr.enums;

public enum Data {
	ORACLE,XMLFILES,QUARKFILES,SYSBASE,MYSQL,HIBERNATE
}
