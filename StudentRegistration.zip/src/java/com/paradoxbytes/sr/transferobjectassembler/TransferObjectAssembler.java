/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.paradoxbytes.sr.transferobjectassembler;


import com.paradoxbytes.sr.to.ProjectDetailsDataTO;

/**
 *
 * @author Loric Madramootoo
 */

public class TransferObjectAssembler implements TransferObjectAssemblerRemote {


    public ProjectDetailsDataTO getStudentInformation(int studentid){
        
       ProjectDetailsDataTO pData = new ProjectDetailsDataTO();
       pData.createStudentInformationResourceTO(studentid);
       
       return pData;
        
        
    }

    public ProjectDetailsDataTO getAllCourses(){
       
       ProjectDetailsDataTO pData = new ProjectDetailsDataTO();
       pData.createCourseInformationResourceTO();
       
       return pData;
        
        
    }


    public ProjectDetailsDataTO updateCourses(int studentid, int courseid){

        ProjectDetailsDataTO pData = new ProjectDetailsDataTO();
        pData.isStudentCourseSelected(studentid, courseid);

        return pData;

    
    }
   

}
