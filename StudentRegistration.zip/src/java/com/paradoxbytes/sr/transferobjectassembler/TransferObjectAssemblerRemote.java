/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.paradoxbytes.sr.transferobjectassembler;

import com.paradoxbytes.sr.to.ProjectDetailsDataTO;

/**
 *
 * @author Loric Madramootoo
 */

public interface TransferObjectAssemblerRemote {

    
    ProjectDetailsDataTO getStudentInformation(int studentid);

    ProjectDetailsDataTO getAllCourses();

    ProjectDetailsDataTO updateCourses(int studentid, int courseid);

    
}
