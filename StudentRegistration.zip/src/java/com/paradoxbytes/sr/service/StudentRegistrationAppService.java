/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.paradoxbytes.sr.service;

import com.paradoxbytes.sr.to.Student;
import com.paradoxbytes.sr.transferobjectassembler.TransferObjectAssembler;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 *
 * @author Loric Madramootoo
 */
public class StudentRegistrationAppService {

    protected transient TransferObjectAssembler session;

    private final Log LOG = LogFactory.getLog(StudentRegistrationAppService.class);

    public StudentRegistrationAppService() {

        this.session = new TransferObjectAssembler();

    }

    public Student getStudentInformation(final int studentid){

     return (Student)session.getStudentInformation(studentid).getStudentInformation();

    }


    public Collection getCourses(){

      return  session.getAllCourses().getCourseInformation();

    }


    public boolean updateCourses(final int studentid, final int courseid){


        return session.updateCourses(studentid, courseid).isIsCourseSelected();

    }




}
