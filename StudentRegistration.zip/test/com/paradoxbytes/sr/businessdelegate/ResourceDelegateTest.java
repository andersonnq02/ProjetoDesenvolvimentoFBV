/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.paradoxbytes.sr.businessdelegate;

import com.paradoxbytes.sr.to.Course;
import com.paradoxbytes.sr.to.Student;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import junit.framework.TestCase;

/**
 *
 * @author Loric Madramootoo
 */
public class ResourceDelegateTest extends TestCase {
    
    public ResourceDelegateTest(String testName) {
        super(testName);
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

//    public void testGetStudentInformation() {
//        System.out.println("**ResourceDelegateTest getStudentInformation");
//        int studentid = 1;
//        ResourceDelegate instance = new ResourceDelegate();
//
//        Student result = instance.getStudentInformation(studentid);
//        assertNotNull(result);
//
//        // Get the student information
//        System.out.println("Student name: " + result.getFirstName() + ", " + result.getLastName());
//        System.out.println("Student address: " + result.getAddress());
//        System.out.println("Student courses: ");
//
//        Set set = result.getCourses();
//        Iterator iter = set.iterator();
//        while (iter.hasNext()) {
//
//            List <Course> courses = (List <Course>)iter.next();
//
//            for(Course course: courses){
//
//                System.out.println("Course name: " + course.getCourseName());
//
//
//            }
//
//        }
//
//
//
//    }
//
//    public void testGetCourses() {
//        System.out.println("**ResourceDelegateTest getCourses");
//        ResourceDelegate instance = new ResourceDelegate();
//        Collection result = instance.getCourses();
//
//
//        assertNotNull(result);
//
//        // Iterate the colleciton
//        Iterator iterator = result.iterator();
//
//         while (iterator.hasNext()) {
//
//             Course course = (Course)iterator.next();
//             System.out.println("Course name: " + course.getCourseName());
//
//        }
//
//
//
//    }


    public void testUpdateCourses(){
     System.out.println("**ResourceDelegateTest testUpdateCourses");
     ResourceDelegate instance = new ResourceDelegate();

     final int studentid = 1;
     final int courseid = 4;

     boolean result = instance.updateCourses(studentid, courseid);

     assertEquals(result,true);




    }






}
