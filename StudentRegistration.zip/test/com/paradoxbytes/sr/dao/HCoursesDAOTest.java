/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.paradoxbytes.sr.dao;

import com.paradoxbytes.sr.to.Course;
import java.util.List;
import junit.framework.TestCase;

/**
 *
 * @author Loric Madramootoo
 */
public class HCoursesDAOTest extends TestCase {
    
    public HCoursesDAOTest(String testName) {
        super(testName);
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testGetAllCourses() {
        System.out.println("**HCoursesDAOTest getAllCourses**");
        HCoursesDAO instance = new HCoursesDAO();
        
        List<Course> courses = instance.getAllCourses();
        
        for(Course course: courses){
            
            System.out.println(course.getCourseId());
            System.out.println(course.getCourseName());
            System.out.println(course.getDescription());
            
        }


        
    }

    public void testGetSpecificCourses() {
        System.out.println("**HCoursesDAOTest getSpecificCourses**");
        int studentid = 1;

        HCoursesDAO instance = new HCoursesDAO();
        List expResult = null;
        
        List<Course> courses = instance.getSpecificCourses(studentid);

        for(Course course: courses){

            System.out.println(course.getCourseId());
            System.out.println(course.getCourseName());
            System.out.println(course.getDescription());

        }


    }

    public void testGetCourseCount() {
        System.out.println("getCourseCount");
        int studentid = 1;
        int courseid = 1;
        HCoursesDAO instance = new HCoursesDAO();
        
        int result = instance.getCourseCount(studentid, courseid);
        System.out.println(result);
    }

}
